abstract public class Shape{
    abstract public double calculateArea();
}