public class Employee
{
    private String name;
    private float salary;
    private float netsalary;
    public void setName(String a2)
    {
        name=a2;
    }
    public void setSalary(float b2)
    {
        salary=b2;
    }
    public void setNetsalary(float c2)
    {
        netsalary=c2;
    }
    public String getName()
    {
        return name;
    }
    public float getSalary()
    {
        return salary;
    }
    public float getNetsalary()
    {
        return netsalary;
    }
}