public abstract class Person
{
//include the attribute specified in the question
String name;

}