public interface Insurance{
    public abstract double takeInsurance();
}