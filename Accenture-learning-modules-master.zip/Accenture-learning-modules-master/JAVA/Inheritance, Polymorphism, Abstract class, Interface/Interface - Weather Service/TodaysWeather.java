public interface TodaysWeather{
    public String location[]={"Delhi","Mumbai","Chennai","Kolkata"};
    public String weather[]={"SUNNY","RAINING","WINDY","SUNNY"};
    public String getWeather(String location);
}