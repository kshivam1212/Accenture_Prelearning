update schedule set TRAVEL_DATE=TRAVEL_DATE+5 where (SOURCE='Chennai' and DESTINATION='Bangalore');
