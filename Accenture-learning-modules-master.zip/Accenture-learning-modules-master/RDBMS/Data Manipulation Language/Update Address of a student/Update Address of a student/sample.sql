update student set Street = 'Andheri West' WHERE FirstName = 'Abdul';
update student set City = 'Mumbai' WHERE FirstName = 'Abdul';