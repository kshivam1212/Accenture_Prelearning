insert into student values(1, 'Anandhi', 'LMC', 'Coimbatore', 1);
insert into student values(2, 'Anitha', 'ABC', 'Salem', 2);