UPDATE Course SET 
Fees = Fees - 500 WHERE 
Duration<=3;