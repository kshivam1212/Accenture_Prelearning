INSERT INTO CUSTOMER_INFO(CUSTOMER_ID,CUSTOMER_NAME,ADDRESS,EMAIL)VALUES('C01','Mary','Delhi','mary@gmail.com');
insert into CUSTOMER_INFO(CUSTOMER_ID,CUSTOMER_NAME,ADDRESS,EMAIL)values('C02','Hema','Bangalore','hema@yahoo.com');
insert into CUSTOMER_INFO(CUSTOMER_ID,CUSTOMER_NAME,ADDRESS,EMAIL)values('C03','Rocky','Chennai','rocky12@gmail.com');
insert into CUSTOMER_INFO(CUSTOMER_ID,CUSTOMER_NAME,ADDRESS,EMAIL)values('C04','Robin','Mumbai','robbywood@yahoo.co.in');
insert into CUSTOMER_INFO(CUSTOMER_ID,CUSTOMER_NAME,ADDRESS,EMAIL)values('C05','Swetha','Hyderabad','Swethu1993@gmail.com');