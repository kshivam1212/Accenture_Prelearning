insert into course values(1001, 'Java', 4, 5000);
insert into course values(1002, 'C++', 2, 4000);
insert into course values(1003, 'Linux and C', 3, 4000);
insert into course values(1004, 'Oracle', 2, 3000);
insert into course values(1005, 'CSharpe', 6, 10000);