insert into student values(3001, 'Dileep','Kumar', 'JaiNagar', 'Bangalore', '10-March-1999');
insert into student values(3002, 'Anand', 'Kumar', 'Indiranagar', 'Bangalore', '19-January-1998');
insert into student values(3003, 'Bala', 'Krishnan', 'Annanagar', 'Chennai', '03-January-1996');
insert into student values(3004, 'Gowri', 'Shankar', 'Gandhipuram','Coimbatore', '22-December-1997');
insert into student values(3005, 'Priya', 'Menon', 'JPNagar', 'Cochin', '12-February-1994');