insert into subject values(1, 'English', 'E1', 2);
insert into subject values(2, 'Maths', 'M1', 4);
insert into subject values(3, 'Physics', 'P1', 1);