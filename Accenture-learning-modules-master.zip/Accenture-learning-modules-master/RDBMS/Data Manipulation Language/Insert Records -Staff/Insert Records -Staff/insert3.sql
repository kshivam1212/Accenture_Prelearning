insert into staff values(3, 'Senthil', 2);
insert into staff values(4, 'Santhya', 2);
insert into staff values(5, 'Geetha', 3);
