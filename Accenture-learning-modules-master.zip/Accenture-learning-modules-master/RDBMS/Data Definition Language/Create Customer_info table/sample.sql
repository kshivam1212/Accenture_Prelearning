create table  Customer_info(
Customer_ID varchar(10) primary key,
Customer_Name varchar(20),
Address varchar(100),
Mobile number(10),
Email varchar(30));