drop table registration;
drop table student;