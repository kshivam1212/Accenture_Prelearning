create table distributor(
    distributor_id varchar(10),
    distributor_name varchar(20),
    address varchar(100),
    mobilenumber number(10),
    email varchar(30),
    primary key(distributor_id)
    );