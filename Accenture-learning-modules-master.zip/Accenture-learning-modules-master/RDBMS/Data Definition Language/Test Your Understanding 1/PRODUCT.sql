create TABLE product
 ( prod_id number(4),
  prod_name varchar(25),
  prod_expiry_date date NOT NULL,
  primary key(prod_id)
); 