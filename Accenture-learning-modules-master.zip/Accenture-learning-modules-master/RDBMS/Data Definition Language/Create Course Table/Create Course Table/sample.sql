create table course(
courseid number(4),
CourseName varchar2(20),
Duration number(2),
Fees number(7,2),
primary key(courseid)
);