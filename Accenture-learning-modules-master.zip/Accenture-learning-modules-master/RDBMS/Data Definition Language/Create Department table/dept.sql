create table department(
department_id number(10) ,
department_name varchar(30),
department_block_number number(10),
constraint PK primary key(department_id)
);