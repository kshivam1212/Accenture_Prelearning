select UPPER(Customer_name) as UPPER_NAME from Customer_Info ORDER BY 
Customer_name asc;