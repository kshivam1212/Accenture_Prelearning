select student_id,address from
student
where initcap(student_name)='David';