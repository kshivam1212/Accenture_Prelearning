Select salesid,to_char(sales_date,'yyyy-mm-dd')as FORMATTED_DATE from sales_info 
order by salesid asc; 
